package com.example.items

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.firebase.Timestamp
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*
import kotlin.collections.HashMap

class TaskRepository(val app: Application) {
    private val db = Firebase.firestore

    val taskList = MutableLiveData<List<ToDoItem>>()
    //private val allData : MutableMap<>

    init{
        db.collection("tasks").addSnapshotListener { snapshot, e ->
            if(e != null){
                Log.i("Error", "Firebase listen failed", e)
                return@addSnapshotListener
            }
            if(snapshot != null){
                parseAllData(snapshot)
            } else {
                Log.w("Error", "Data is null")
            }
        }
    }

    private fun parseAllData(result: QuerySnapshot) {
        var allTasks = mutableListOf<ToDoItem>()
        val drawable = R.drawable.to_do_icon
        for(doc in result){
            val id: Int = doc.id.toInt()
            val toDoText: String = doc.getString("todomsg")!!
            val dateAdded: Date = (doc.get("date") as Timestamp).toDate()

            allTasks.add(ToDoItem(
                id,
                drawable,
                toDoText,
                dateAdded,
                false
            ))
        }

        taskList.value = allTasks
        Log.i("Fb data", "All data: $allTasks")
    }

    private fun taskDetailsToHashMap(task: ToDoItem): HashMap<String, *>{
        return hashMapOf(
            "id" to task.task_id,
            "todomsg" to task.toDoText,
            "date" to task.dateAdded
        )
    }


    fun addTask(task: ToDoItem){
        val taskMap = taskDetailsToHashMap(task)

        db.collection("tasks").document(task.task_id.toString())
            .set(taskMap)
            .addOnSuccessListener {
                Log.i("FIREBASE", "Successfully added task to database")
            }
            .addOnFailureListener {
                Log.i("FIREBASE", "error adding new task", it)
            }
    }

    fun removeTask(id: Int){
        db.collection("tasks").document(id.toString()).delete()
    }

}