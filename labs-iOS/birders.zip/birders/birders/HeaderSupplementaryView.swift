//
//  HeaderSupplementaryView.swift
//  birders
//
//  Created by Elsa Roeber on 2/28/20.
//  Copyright © 2020 Elsa Roeber. All rights reserved.
//

import UIKit

class HeaderSupplementaryView: UICollectionReusableView {
    @IBOutlet weak var headerLabel: UILabel!
    
}
