//
//  FooterSupplementaryViewCollectionReusableView.swift
//  birders
//
//  Created by Elsa Roeber on 2/29/20.
//  Copyright © 2020 Elsa Roeber. All rights reserved.
//

import UIKit

class FooterSupplementaryViewCollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var footerLabel: UILabel!
    
}
