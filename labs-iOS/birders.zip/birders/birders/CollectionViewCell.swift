//
//  CollectionViewCell.swift
//  birders
//
//  Created by Elsa Roeber on 2/27/20.
//  Copyright © 2020 Elsa Roeber. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
}
